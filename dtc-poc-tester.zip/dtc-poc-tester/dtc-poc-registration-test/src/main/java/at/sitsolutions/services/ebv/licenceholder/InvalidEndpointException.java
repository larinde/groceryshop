/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */

package at.sitsolutions.services.ebv.licenceholder;

public class InvalidEndpointException extends RuntimeException {

	private static final long serialVersionUID = -8668273088074480149L;

}
