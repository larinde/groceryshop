/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */
package at.sitsolutions.services.ebv.licenceholder.stories;

import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import at.sitsolutions.services.ebv.licenceholder.AcceptanceTestConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@DirtiesContext
@ComponentScan
@ContextConfiguration(classes=AcceptanceTestConfiguration.class)
public class LicenceHolderJBehaveStory extends AbstractEbvJBehaveStory {


}
