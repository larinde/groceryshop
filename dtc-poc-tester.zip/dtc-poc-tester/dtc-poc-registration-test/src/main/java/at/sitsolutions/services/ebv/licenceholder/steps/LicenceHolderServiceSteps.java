/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */
package at.sitsolutions.services.ebv.licenceholder.steps;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.*;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Pending;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import at.sitsolutions.services.ebv.licenceholder.LicenceHolderRestClient;

@Component
public class LicenceHolderServiceSteps {

    private final LicenceHolderRestClient licenceHolderRestClient;

    @Autowired
    public LicenceHolderServiceSteps(LicenceHolderRestClient licenceHolderRestClient) {
        super();
        this.licenceHolderRestClient = licenceHolderRestClient;
    }

    @Then("they should receive an empty list of contact persons")
//    @Pending
    public void thenTheyShouldReceiveAnEmptyListOfContactPersons() {
    	fail("unimplemente");
    }

    @Given("Given: an ineligible licence holder")
    public void givenGivenAnIneligibleLicenceHolder() {
        assertThat(licenceHolderRestClient, is(notNullValue()));
    }

    @Given("an eligible licence holder with user number $userNumber")
//    @Pending
    public void eligibleLicenceHolder(String userNumber) {
        // TODO
    }

    @Given("an ineligible licence holder with user number $userNum")
    @Pending
    public void ineligibleLicenceHolder(String userNum) {
        // TODO
    }

    @When("they request their list of contact persons")
    @Pending
    public void requestListOfContactPersons() {
        // TODO
    }

    @Then("they should receive an HTTP 404 error response code")
    @Pending
    public void notFoundErrorResponse() {
        // TODO
    }

    @Then("they should receive a list of $numberOfContacts contact persons")
    @Pending
    public void responseListOfContactPersons(Integer numberOfContacts) {
        // TODO
    }
}
