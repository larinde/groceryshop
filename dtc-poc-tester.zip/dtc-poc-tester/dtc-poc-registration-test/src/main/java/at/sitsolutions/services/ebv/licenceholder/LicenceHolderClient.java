/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */
package at.sitsolutions.services.ebv.licenceholder;

import java.util.Collection;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

import at.sitsolutions.services.ebv.licenceholder.representation.ContactPersonRto;
import at.sitsolutions.services.ebv.licenceholder.representation.ContactPersonViewInRto;

public interface LicenceHolderClient {

    public abstract ContactPersonRto createContactPerson(@Digits(integer=9, fraction=0) Integer userNumber, @Valid ContactPersonViewInRto contactPersonViewInRto);

    public abstract Collection<ContactPersonRto> readContactPersons(@Digits(integer=9, fraction=0) Integer userNumber, @Size(max=16) String customerId);

    public abstract ContactPersonRto updateContactPerson(@Digits(integer=9, fraction=0) Integer userNumber, @Size(max=36) String id, @Valid ContactPersonRto contactPersonRto);

}
