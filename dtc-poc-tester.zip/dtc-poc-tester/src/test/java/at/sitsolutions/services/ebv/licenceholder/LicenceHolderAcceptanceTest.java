package at.sitsolutions.services.ebv.licenceholder;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty",
                            "html:target/acceptance_test_report_html",
                            "json:target/acceptance_test_report" })
public class LicenceHolderAcceptanceTest {
}
