package at.sitsolutions.services.ebv.licenceholder;

import java.util.concurrent.ConcurrentHashMap;

import at.sitsolutions.pepper.application.web.jetty.JettyServerBuilder;
import at.sitsolutions.pepper.application.web.jetty.StartJettyApp;

import org.eclipse.jetty.annotations.AnnotationConfiguration;
import org.eclipse.jetty.annotations.ClassInheritanceHandler;
import org.eclipse.jetty.util.ConcurrentHashSet;
import org.eclipse.jetty.webapp.Configuration;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.webapp.WebXmlConfiguration;
import org.springframework.web.WebApplicationInitializer;

/**
 * Helper class to configure and launch jetty server.
 *
 * @author s3873 - martin.kaderabek@s-itsolutions.at
 * @since 11.05.2014
 */
public class StartJetty extends StartJettyApp {

    private static final String PATH_JETTY_PROPERTIES = "etc/jetty/jetty-system.properties";
    private static final int JETTY_PORT = 9999;
    private static final StartJetty jetty = new StartJetty();;

	@Override
    protected void withBuilder(JettyServerBuilder builder) {
        builder
            .loadFromPropertiesFile(PATH_JETTY_PROPERTIES)
            .progressIndicatorEnabled(true)
            .setConfigurations(getConfigurations())
            .contextPath("/ebv-licenceholder")
//            .contextPath("/" + PepperWebApplicationInitializer.APPLICATION_NAME)
            .prepareOracleDataSource().jndiName("ebvpool").url("jdbc:oracle:thin:@datacashd.server.lan.at:1521/ebvd10.datacashd").username("EBVWARTG").password("wart4ebv").register()
            .port(Integer.getInteger("jettyPort", JETTY_PORT));
    }

	public static void start() {
		jetty.startInteractive();
	}

//	public static void stop() {
//		jetty.stop();
//	}

    private Configuration[] getConfigurations() {
        return new Configuration[] {
            new WebXmlConfiguration(),
            new AnnotationConfiguration() {

                @Override
                public void preConfigure(WebAppContext context) throws Exception {
                    ConcurrentHashMap<String, ConcurrentHashSet<String>> map = new ConcurrentHashMap<String, ConcurrentHashSet<String>>();
                    ConcurrentHashSet<String> set = new ConcurrentHashSet<>();
//                    set.add(PepperWebApplicationInitializer.class.getName());
                    set.add("at.sitsolutions.services.ebv.licenceholder.war.PepperWebApplicationInitializer");
                    map.put(WebApplicationInitializer.class.getName(), set);
                    context.setAttribute(CLASS_INHERITANCE_MAP, map);
                    _classInheritanceHandler = new ClassInheritanceHandler(map);
                }
            }
        };
    }
}
