/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */

package at.sitsolutions.services.ebv.licenceholder.hooks;

import at.sitsolutions.pepper.application.web.jetty.JettyServer;
import at.sitsolutions.services.ebv.licenceholder.StartJetty;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ServerHook {

    private static JettyServer jettyServer;

    @Before("@startServer")
    public static void initLocalServer() throws Exception {
        System.out.println("======== STARTING LOCAL SERVER ========");
//        StartJetty _jetty = new StartJetty();
        jettyServer = (new StartJetty()).createServer();
        jettyServer.startInteractive();
    }

    @After("@stopserver")
    public static void shutdownLocalServer() {
        System.out.println("======== SHUTTING DOWN LOCAL SERVER ========");
        jettyServer.stop();
    }
}
