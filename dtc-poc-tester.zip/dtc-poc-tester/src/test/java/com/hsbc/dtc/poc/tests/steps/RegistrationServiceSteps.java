/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */

package com.hsbc.dtc.poc.tests.steps;

import static org.junit.Assert.fail;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationServiceSteps {

    @Given("^an eligible user with user number (\\d+)$")
    public void an_eligible_user_with_user_number(int userNumber) throws Throwable {
        System.out.println("user number = " + userNumber);
        fail("unimplemented");
        // throw new PendingException();
    }

    @Given("^an ineligible user with user number (\\d+)$")
    public void an_ineligible_user_with_user_number(int userNumber) throws Throwable {
        System.out.println("user number = " + userNumber);
        fail("unimplemented");
        // throw new PendingException();
    }

    @When("^they request their list of contact persons$")
    public void they_request_their_list_of_contact_persons() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
        fail("unimplemented");
    }

    @Then("^they should receive a list of (\\d+) contact persons$")
    public void they_should_receive_a_list_of_contact_persons(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
        fail("unimplemented");
    }

    @Then("^they should receive an empty list of contact persons$")
    public void they_should_receive_an_empty_list_of_contact_persons() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
        fail("unimplemented");
    }

    @Then("^they should receive an HTTP (\\d+) error response code$")
    public void they_should_receive_an_HTTP_error_response_code(int httpResponseCode)
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        // throw new PendingException();
        fail("unimplemented");
    }

}
