package com.hsbc.dtc.poc.tests.steps;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SubscriptionRegistrationSteps {
    @Given("^a user with first name (.+), last name (.+) an email account (.+) and user id (.+)$")
    public void userDetails(String firstname, String lastname, String email, String userid) throws Throwable {
        throw new PendingException();
    }

    @When("^they enter their details and subscribe for (.+) service$")
    public void userSubscribedService(String service) throws Throwable {
        throw new PendingException();
    }

    @Then("^they should be registered and subscribed with default currency options$")
    public void userShouldBeSubscribedWithDefaultCurrencyOptions() throws Throwable {
        throw new PendingException();
    }
}
