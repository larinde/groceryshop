/**
 * Koweg Software Solutions Limited
 *
 */

package com.hsbc.dtc.poc.tests.steps;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.jayway.jsonpath.JsonPath;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.*;


/**
 * @author olarinde.ajai@gmail.com
 *
 */
public class OpenAmAuthenticationSteps {

    private static final String OPENAM_USERNAME_HEADER = "X-OpenAM-Username";
    private static final String BASE_URI = "http://localhost:8080/openam";
    private static final String AUTHENTICATION_PATH = "/json/authenticate";
    private static final String OPENAM_PASSWORD_HEADER = "X-OpenAM-Password";
    private WebTarget webTarget;
    private Builder builder;
    private Response response;

    @Given("^a user with valid username \"([^\"]*)\" and a valid password \"([^\"]*)\"$")
    public void a_user_with_valid_username_and_a_valid_password(String username, String password) throws Throwable {
        Client client = ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path(AUTHENTICATION_PATH);
        builder = webTarget.request(MediaType.APPLICATION_JSON_TYPE)
                .header(OPENAM_USERNAME_HEADER, username)
                .header(OPENAM_PASSWORD_HEADER, password);
    }

    @When("^they are authenticated by OpenAM$")
    public void they_are_authenticated_by_OpenAM() throws Throwable {
        response = builder.post(Entity.json(""));
    }

    @Then("^they should receive a token ID and a success url$")
    public void they_should_receive_a_token_ID_and_a_success_url() throws Throwable {
        assertThat(response, is(notNullValue()));
        assertThat(response.getStatus(), is(Status.OK.getStatusCode()));

        String body = response.readEntity(String.class);
        assertThat(body , is(notNullValue()));
        assertThat(JsonPath.parse(body).read("tokenId") , is(notNullValue()));
        assertThat(JsonPath.parse(body).read("successUrl") , is(notNullValue()));
//        System.out.println(body);
//        System.out.println("token = " + JsonPath.parse(body).read("tokenId"));
//        System.out.println("url = " + JsonPath.parse(body).read("successUrl"));



    }

}
