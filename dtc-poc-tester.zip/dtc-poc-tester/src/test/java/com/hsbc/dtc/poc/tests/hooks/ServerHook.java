/*
 * Copyright (c) 2015 s IT Solutions AT Spardat GmbH
 * A-1110 Wien, Geiselbergstr.21-25.
 * All rights reserved.
 */

package com.hsbc.dtc.poc.tests.hooks;

import com.hsbc.dtc.poc.tests.StartJetty;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ServerHook {

}
