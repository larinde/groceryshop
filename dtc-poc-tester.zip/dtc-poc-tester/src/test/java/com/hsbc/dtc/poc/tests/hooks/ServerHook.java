/*
 * Copyright (c) 2016 Koweg Software Solutions Limited
 * London
 * All rights reserved.
 */

package com.hsbc.dtc.poc.tests.hooks;


import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ServerHook {

}
