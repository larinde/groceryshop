package com.hsbc.dtc.poc.tests;

public class InvalidEndpointException extends Exception {

}
