/*
 * Copyright (c) 2016 Koweg Software Solutions Ltd
 * 8 Canada Square
 * London E14 5HQ
 * All rights reserved.
 */
package com.hsbc.dtc.poc.tests;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
public class UserRegistrationRestClient {

//    private static final String BEARER_PREFIX = "bearer ";
//    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String CONTENT_TYPE = "Content-Type";
    private final RestTemplate restTemplate;
    private final String baseUrl;

    @Autowired
    public UserRegistrationRestClient(String baseUrl, RestTemplate restTemplate) {
        this.baseUrl = baseUrl;
        this.restTemplate = restTemplate;
    }

    public ResponseData createRegistration(final Integer userNumber, final RequestData requestData) throws InvalidEndpointException {
        try {
            HttpHeaders httpHeaders = new HttpHeaders();
//            httpHeaders.set(AUTHORIZATION_HEADER, BEARER_PREFIX + userNumber.toString());
            httpHeaders.set(CONTENT_TYPE, "aplication/json");
            URI url = new URI(baseUrl + "/" + "registrations");
            HttpEntity<RequestData> requestEntity = new HttpEntity<>(requestData, httpHeaders);
            ResponseEntity<ResponseData> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, ResponseData.class);
            return responseEntity.getBody();
        } catch (URISyntaxException e) {
            throw new InvalidEndpointException();
        }
    }

    public ResponseData getRegistration(final Integer registrationId) throws InvalidEndpointException {
        try {
            HttpHeaders httpHeaders = new HttpHeaders();
//            httpHeaders.set(AUTHORIZATION_HEADER, BEARER_PREFIX + userNumber.toString());
            URI url = new URI(baseUrl + "/"+registrationId.toString());
            @SuppressWarnings("rawtypes")
            ResponseEntity<ResponseData> responseEntity = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<String>(httpHeaders), ResponseData.class);

            return  responseEntity.getBody();
        } catch (URISyntaxException e) {
            throw new InvalidEndpointException();
        }
    }

}
