/**
 * @startuml
 * 
 * hide footbox
 * 
 * actor User
 * 
 * User -> InvoiceResource: POST: /invoice
 * activate InvoiceResource
 * 
 * InvoiceResource -> InvoiceActor:onReceive
 * 
 * 
 * @enduml
 * 
 */
package com.koweg.accounts.invoice;

/**
 * @author larinde
 *
 */
@FunctionalInterface
public interface InvoiceService {
    
    public void saveInvoice();

}
