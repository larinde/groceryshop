package com.koweg.accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountingWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountingWebApplication.class, args);
	}
}
