/**
 * 
 */
/**
 * @author larinde
 *
 */
package com.koweg.accounts.api.resource.websocket;