/**
 * Koweg Software Solutions Limited
 *
 */

package com.koweg.accounts.api.resource.impl;

import com.koweg.accounts.api.model.Invoice_;
import com.koweg.accounts.api.resource.InvoicesResource;

/**
 * @author olarinde.ajai@gmail.com
 *
 */
public class InvoicesResourceImpl implements InvoicesResource {

    @Override
    public GetInvoicesResponse getInvoices(String authorization, String xApiVersion, String fromDate, String toDate, String invoiceType) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public PostInvoicesResponse postInvoices(String authorization, String xApiVersion, Invoice_ entity) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
