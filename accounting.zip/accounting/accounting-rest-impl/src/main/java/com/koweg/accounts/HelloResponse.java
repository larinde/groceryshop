/**
 * 
 */
package com.koweg.accounts;

import lombok.Data;

/**
 * @author larinde
 *
 */
@Data
public class HelloResponse {
    private final int left;
    private final int right;
    private final long answer;
    public HelloResponse(int left, int right, long answer) {
        super();
        this.left = left;
        this.right = right;
        this.answer = answer;
    }

}
