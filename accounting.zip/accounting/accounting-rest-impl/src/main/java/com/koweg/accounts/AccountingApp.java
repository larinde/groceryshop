package com.koweg.accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountingApp {
    public static void main(String[] args) {
        SpringApplication.run(AccountingApp.class, args);
    }
}