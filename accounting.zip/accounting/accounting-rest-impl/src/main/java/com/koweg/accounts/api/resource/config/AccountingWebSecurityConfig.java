/**
 * 
 */
package com.koweg.accounts.api.resource.config;

import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * @author larinde
 *
 */
public class AccountingWebSecurityConfig extends WebSecurityConfigurerAdapter {

}
