package com.koweg.poc.usermgt.rest.resource;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.koweg.poc.usermgt.rest.model.Registration;

@Path("/registrations")
public class RegistrationResource {

    private static final Map<String, Registration> repository;
    private static final AtomicInteger userId = new AtomicInteger(109);

    static {
        repository = new ConcurrentHashMap<>();
        repository.put("100", new Registration("Olarinde", "Ajai", "100"));
        repository.put("103", new Registration("Anna", "Ajai", "103"));
        repository.put("107", new Registration("Ella", "Fitzgerald", "107"));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{userId}")
    public Registration readRegistration(@PathParam("userId") String userId) {
        return repository.get(userId);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Registration createRegistration(Registration registration) {
        if (repository.containsKey(registration.getUserId())) {
            return registration;
        } else {
            registration.setUserId(String.valueOf(userId.incrementAndGet()));
            repository.put(registration.getUserId(), registration);
            return registration;
        }
    }

}
