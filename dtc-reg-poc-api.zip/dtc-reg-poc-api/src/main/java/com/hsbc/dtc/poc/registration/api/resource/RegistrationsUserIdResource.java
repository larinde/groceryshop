
package com.hsbc.dtc.poc.registration.api.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import com.hsbc.dtc.poc.registration.api.model.Partialregistration;
import com.hsbc.dtc.poc.registration.api.model.Registration_;
import com.hsbc.dtc.poc.registration.api.resource.support.PATCH;

@Path("registrations/{userId}")
public interface RegistrationsUserIdResource {


    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param userId
     *     
     */
    @GET
    @Produces({
        "application/json"
    })
    RegistrationsUserIdResource.GetRegistrationsByUserIdResponse getRegistrationsByUserId(
        @PathParam("userId")
        String userId,
        @HeaderParam("x-api-version")
        String xApiVersion)
        throws Exception
    ;

    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param userId
     *     
     * @param entity
     *      e.g. {
     *       "lastname": "Khan",
     *       "serviceType": "curr_historic_rates"
     *     }
     *     
     */
    @PATCH
    @Consumes("application/json")
    @Produces({
        "application/json"
    })
    RegistrationsUserIdResource.PatchRegistrationsByUserIdResponse patchRegistrationsByUserId(
        @PathParam("userId")
        String userId,
        @HeaderParam("x-api-version")
        String xApiVersion, Partialregistration entity)
        throws Exception
    ;

    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param userId
     *     
     */
    @DELETE
    RegistrationsUserIdResource.DeleteRegistrationsByUserIdResponse deleteRegistrationsByUserId(
        @PathParam("userId")
        String userId,
        @HeaderParam("x-api-version")
        String xApiVersion)
        throws Exception
    ;

    public class DeleteRegistrationsByUserIdResponse
        extends com.hsbc.dtc.poc.registration.api.resource.support.ResponseWrapper
    {


        private DeleteRegistrationsByUserIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         * 
         */
        public static RegistrationsUserIdResource.DeleteRegistrationsByUserIdResponse withNoContent() {
            Response.ResponseBuilder responseBuilder = Response.status(204);
            return new RegistrationsUserIdResource.DeleteRegistrationsByUserIdResponse(responseBuilder.build());
        }

    }

    public class GetRegistrationsByUserIdResponse
        extends com.hsbc.dtc.poc.registration.api.resource.support.ResponseWrapper
    {


        private GetRegistrationsByUserIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         *  e.g. {
         *   "firstname": "Max",
         *   "lastname": "Mustermann",
         *   "email": "max.mustermann@test.hsbc.com",
         *   "serviceType": "curr_live_rates"
         * }
         * 
         * 
         * @param entity
         *     {
         *       "firstname": "Max",
         *       "lastname": "Mustermann",
         *       "email": "max.mustermann@test.hsbc.com",
         *       "serviceType": "curr_live_rates"
         *     }
         *     
         */
        public static RegistrationsUserIdResource.GetRegistrationsByUserIdResponse withJsonOK(Registration_ entity) {
            Response.ResponseBuilder responseBuilder = Response.status(200).header("Content-Type", "application/json");
            responseBuilder.entity(entity);
            return new RegistrationsUserIdResource.GetRegistrationsByUserIdResponse(responseBuilder.build());
        }

    }

    public class PatchRegistrationsByUserIdResponse
        extends com.hsbc.dtc.poc.registration.api.resource.support.ResponseWrapper
    {


        private PatchRegistrationsByUserIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         *  e.g. {
         *   "firstname": "Max",
         *   "lastname": "Mustermann",
         *   "email": "max.mustermann@test.hsbc.com",
         *   "serviceType": "curr_live_rates"
         * }
         * 
         * 
         * @param entity
         *     {
         *       "firstname": "Max",
         *       "lastname": "Mustermann",
         *       "email": "max.mustermann@test.hsbc.com",
         *       "serviceType": "curr_live_rates"
         *     }
         *     
         */
        public static RegistrationsUserIdResource.PatchRegistrationsByUserIdResponse withJsonOK(Partialregistration entity) {
            Response.ResponseBuilder responseBuilder = Response.status(200).header("Content-Type", "application/json");
            responseBuilder.entity(entity);
            return new RegistrationsUserIdResource.PatchRegistrationsByUserIdResponse(responseBuilder.build());
        }

    }

}
