
package com.hsbc.dtc.poc.registration.api.model;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "userId",
    "firstname",
    "lastname",
    "email",
    "subscriptions"
})
public class Registration_ {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("userId")
    private String userId;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("firstname")
    private String firstname;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("lastname")
    private String lastname;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("email")
    private String email;
    @JsonProperty("subscriptions")
    @JsonDeserialize(as = java.util.LinkedHashSet.class)
    private Set<Subscription_> subscriptions = new LinkedHashSet<Subscription_>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * (Required)
     * 
     * @return
     *     The userId
     */
    @JsonProperty("userId")
    public String getUserId() {
        return userId;
    }

    /**
     * 
     * (Required)
     * 
     * @param userId
     *     The userId
     */
    @JsonProperty("userId")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Registration_ withUserId(String userId) {
        this.userId = userId;
        return this;
    }

    /**
     * 
     * (Required)
     * 
     * @return
     *     The firstname
     */
    @JsonProperty("firstname")
    public String getFirstname() {
        return firstname;
    }

    /**
     * 
     * (Required)
     * 
     * @param firstname
     *     The firstname
     */
    @JsonProperty("firstname")
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public Registration_ withFirstname(String firstname) {
        this.firstname = firstname;
        return this;
    }

    /**
     * 
     * (Required)
     * 
     * @return
     *     The lastname
     */
    @JsonProperty("lastname")
    public String getLastname() {
        return lastname;
    }

    /**
     * 
     * (Required)
     * 
     * @param lastname
     *     The lastname
     */
    @JsonProperty("lastname")
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Registration_ withLastname(String lastname) {
        this.lastname = lastname;
        return this;
    }

    /**
     * 
     * (Required)
     * 
     * @return
     *     The email
     */
    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    /**
     * 
     * (Required)
     * 
     * @param email
     *     The email
     */
    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public Registration_ withEmail(String email) {
        this.email = email;
        return this;
    }

    /**
     * 
     * @return
     *     The subscriptions
     */
    @JsonProperty("subscriptions")
    public Set<Subscription_> getSubscriptions() {
        return subscriptions;
    }

    /**
     * 
     * @param subscriptions
     *     The subscriptions
     */
    @JsonProperty("subscriptions")
    public void setSubscriptions(Set<Subscription_> subscriptions) {
        this.subscriptions = subscriptions;
    }

    public Registration_ withSubscriptions(Set<Subscription_> subscriptions) {
        this.subscriptions = subscriptions;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Registration_ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
