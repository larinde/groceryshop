
package com.hsbc.dtc.poc.registration.api.model;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "firstname",
    "lastname",
    "email",
    "subscriptions"
})
public class Partialregistration {

    @JsonProperty("firstname")
    private String firstname;
    @JsonProperty("lastname")
    private String lastname;
    @JsonProperty("email")
    private String email;
    @JsonProperty("subscriptions")
    @JsonDeserialize(as = java.util.LinkedHashSet.class)
    private Set<Subscription__> subscriptions = new LinkedHashSet<Subscription__>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * @return
     *     The firstname
     */
    @JsonProperty("firstname")
    public String getFirstname() {
        return firstname;
    }

    /**
     * 
     * @param firstname
     *     The firstname
     */
    @JsonProperty("firstname")
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public Partialregistration withFirstname(String firstname) {
        this.firstname = firstname;
        return this;
    }

    /**
     * 
     * @return
     *     The lastname
     */
    @JsonProperty("lastname")
    public String getLastname() {
        return lastname;
    }

    /**
     * 
     * @param lastname
     *     The lastname
     */
    @JsonProperty("lastname")
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public Partialregistration withLastname(String lastname) {
        this.lastname = lastname;
        return this;
    }

    /**
     * 
     * @return
     *     The email
     */
    @JsonProperty("email")
    public String getEmail() {
        return email;
    }

    /**
     * 
     * @param email
     *     The email
     */
    @JsonProperty("email")
    public void setEmail(String email) {
        this.email = email;
    }

    public Partialregistration withEmail(String email) {
        this.email = email;
        return this;
    }

    /**
     * 
     * @return
     *     The subscriptions
     */
    @JsonProperty("subscriptions")
    public Set<Subscription__> getSubscriptions() {
        return subscriptions;
    }

    /**
     * 
     * @param subscriptions
     *     The subscriptions
     */
    @JsonProperty("subscriptions")
    public void setSubscriptions(Set<Subscription__> subscriptions) {
        this.subscriptions = subscriptions;
    }

    public Partialregistration withSubscriptions(Set<Subscription__> subscriptions) {
        this.subscriptions = subscriptions;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Partialregistration withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

}
