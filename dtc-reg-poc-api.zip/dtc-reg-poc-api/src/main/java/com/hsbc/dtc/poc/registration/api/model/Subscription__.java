
package com.hsbc.dtc.poc.registration.api.model;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "serviceType",
    "currencyPairs"
})
public class Subscription__ {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("serviceType")
    private Subscription__.ServiceType serviceType;
    @JsonProperty("currencyPairs")
    @JsonDeserialize(as = java.util.LinkedHashSet.class)
    private Set<String> currencyPairs = new LinkedHashSet<String>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * 
     * (Required)
     * 
     * @return
     *     The serviceType
     */
    @JsonProperty("serviceType")
    public Subscription__.ServiceType getServiceType() {
        return serviceType;
    }

    /**
     * 
     * (Required)
     * 
     * @param serviceType
     *     The serviceType
     */
    @JsonProperty("serviceType")
    public void setServiceType(Subscription__.ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public Subscription__ withServiceType(Subscription__.ServiceType serviceType) {
        this.serviceType = serviceType;
        return this;
    }

    /**
     * 
     * @return
     *     The currencyPairs
     */
    @JsonProperty("currencyPairs")
    public Set<String> getCurrencyPairs() {
        return currencyPairs;
    }

    /**
     * 
     * @param currencyPairs
     *     The currencyPairs
     */
    @JsonProperty("currencyPairs")
    public void setCurrencyPairs(Set<String> currencyPairs) {
        this.currencyPairs = currencyPairs;
    }

    public Subscription__ withCurrencyPairs(Set<String> currencyPairs) {
        this.currencyPairs = currencyPairs;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Subscription__ withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Generated("org.jsonschema2pojo")
    public static enum ServiceType {

        CURR_HISTORIC_RATES("curr_historic_rates"),
        CURR_LIVE_RATES("curr_live_rates");
        private final String value;
        private final static Map<String, Subscription__.ServiceType> CONSTANTS = new HashMap<String, Subscription__.ServiceType>();

        static {
            for (Subscription__.ServiceType c: values()) {
                CONSTANTS.put(c.value, c);
            }
        }

        private ServiceType(String value) {
            this.value = value;
        }

        @JsonValue
        @Override
        public String toString() {
            return this.value;
        }

        @JsonCreator
        public static Subscription__.ServiceType fromValue(String value) {
            Subscription__.ServiceType constant = CONSTANTS.get(value);
            if (constant == null) {
                throw new IllegalArgumentException(value);
            } else {
                return constant;
            }
        }

    }

}
