{
  "userId" : "43997491",
  "firstname" : "John",
  "lastname" : "Doe",
  "serviceType" : "curr_historic_rates"
}
