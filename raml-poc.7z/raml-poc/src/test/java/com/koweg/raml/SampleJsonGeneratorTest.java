package com.koweg.raml;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koweg.registration.api.model.Registration;
import com.koweg.registration.api.model.Registration.ServiceType;

public class SampleJsonGeneratorTest {

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Registration registration = new Registration();
        registration.setFirstname("John");
        registration.setLastname("Doe");
        registration.setServiceType(ServiceType.CURR_HISTORIC_RATES);
        registration.setUserId("43997491");
        String output = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(registration);
        System.out.println(output);
    }

}
