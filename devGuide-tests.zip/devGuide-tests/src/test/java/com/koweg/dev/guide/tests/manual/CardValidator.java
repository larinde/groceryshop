/**
 * 
 */
package com.koweg.dev.guide.tests.manual;

import org.apache.commons.validator.routines.CreditCardValidator;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

/**
 * @author larinde
 *
 */
@Component
public class CardValidator {

    private final CreditCardValidator validator = new CreditCardValidator(CreditCardValidator.AMEX);

    @Cacheable("panValidationCache")
    public CardInfo isValid(String pan) {
        System.out.println("cache miss");
        return new CardInfo(pan, validator.isValid(pan));
    }

}
