/**
 * 
 */
package com.koweg.dev.guide.tests.manual;

/**
 * @author larinde
 *
 */
public class CardInfo {
    private final String pan;
    private final boolean valid;

    public CardInfo(String pan, boolean valid) {
        super();
        this.pan = pan;
        this.valid = valid;
    }

    public String getPan() {
        return pan;
    }

    public boolean isValid() {
        return valid;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((pan == null) ? 0 : pan.hashCode());
        result = prime * result + (valid ? 1231 : 1237);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CardInfo other = (CardInfo) obj;
        if (pan == null) {
            if (other.pan != null)
                return false;
        } else if (!pan.equals(other.pan))
            return false;
        if (valid != other.valid)
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "CardInfo [pan=" + pan + ", valid=" + valid + "]";
    }

}
