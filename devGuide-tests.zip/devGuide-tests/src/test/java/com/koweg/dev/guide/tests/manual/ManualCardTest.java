package com.koweg.dev.guide.tests.manual;

import static org.junit.Assert.*;
import static org.hamcrest.core.Is.isA;
import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.hamcrest.CoreMatchers.hasItem;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.commons.validator.routines.CreditCardValidator;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = CardValidatorConfig.class)
public class ManualCardTest {

    @Autowired
    private TestDataLoader testDataLoader;

    @Autowired
    private PooledPBEStringEncryptor encryptor;

    @Autowired
    private CardValidator cardValidator;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void shouldBeCorrectlyWired() {
        assertNotNull(testDataLoader);
        assertNotNull(cardValidator);
    }

    @Test
    public void shouldLoadAndValidateFiftyAmexCards() throws IOException {
        List<TestCard> amexCards = testDataLoader.loadAmexCards();
        assertThat(amexCards, is(notNullValue()));
        assertThat(amexCards.size(), equalTo(50));

        CreditCardValidator validator = new CreditCardValidator(CreditCardValidator.AMEX);

//        for (TestCard card : amexCards) {
//            assertThat(validator.isValid(encryptor.decrypt(card.getPan())), equalTo(true));
//        }
        
        for (TestCard card : amexCards) {
            System.out.println("validating cache");
            assertThat(cardValidator.isValid(encryptor.decrypt(card.getPan())).isValid(), equalTo(true));
        }
        for (TestCard card : amexCards) {
            System.out.println("validating cache");
            cardValidator.isValid(encryptor.decrypt(card.getPan()));
        }
    }

}
