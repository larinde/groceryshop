/**
 * 
 */
package com.koweg.dev.guide.tests.manual;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.stereotype.Component;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;
import org.supercsv.cellprocessor.Trim;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.cellprocessor.joda.ParseDateTime;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

/**
 * @author larinde
 *
 */
@Component
public class TestDataLoader implements ResourceLoaderAware{

    private final PooledPBEStringEncryptor encryptor;
    private ResourceLoader resourceLoader;

    private final String[] nameMapping = new String[] { "pan", "cid", "expiryDate" };
    private final CellProcessor[] processors;

    private DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("MM/yyyy");

    private final CsvPreference preferences;

    public TestDataLoader(PooledPBEStringEncryptor encryptor) {
        this.encryptor = encryptor;
        this.processors = initProcessors();
        preferences = new CsvPreference.Builder(CsvPreference.STANDARD_PREFERENCE).build();
    }

    private CellProcessor[] initProcessors() {
        // TODO Auto-generated method stub
        return new CellProcessor[] { new Trim(new NotNull()), new Trim(new NotNull()), new ParseDateTime(dateTimeFormatter) };
    }

    public List<TestCard> loadAmexCards() throws IOException {
        ICsvBeanReader reader = null;
        final List<TestCard> amexTestCards = new ArrayList<>();
        try {
            InputStream inputStream;
            inputStream = resourceLoader.getResource("classpath:testdata/cards/testdata_amex_cards.csv").getInputStream();
            reader = new CsvBeanReader(new InputStreamReader(inputStream), preferences);
            reader.getHeader(false);
            TestCard card = null;
            
            while ((card = reader.read(TestCard.class, nameMapping, processors))!=null) {
                amexTestCards.add(card);
            }
        }finally{
            if(reader!=null){
                    reader.close();
            }
        }
        for (TestCard cd : amexTestCards) {
            System.out.println(encryptor.decrypt(cd.getPan()) + "," + cd.getCid() + "," + dateTimeFormatter.print(cd.getExpiryDate()) );
        }
        return amexTestCards;
    }

    @Override
    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }
}
