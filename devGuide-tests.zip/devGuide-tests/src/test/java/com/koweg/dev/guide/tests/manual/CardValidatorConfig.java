package com.koweg.dev.guide.tests.manual;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

@Configuration
@EnableCaching
public class CardValidatorConfig {

    @Bean
    @Autowired
    public TestDataLoader testDataLoader(PooledPBEStringEncryptor encryptor) {
        return new TestDataLoader(encryptor);
    }

    @Bean
    public CacheManager cacheManager() {
        return new EhCacheCacheManager(ehCacheManagerFactoryBean().getObject());
    }

    @Bean
    public EhCacheManagerFactoryBean ehCacheManagerFactoryBean() {
        EhCacheManagerFactoryBean factoryBean = new EhCacheManagerFactoryBean();
        factoryBean.setConfigLocation(new ClassPathResource("ehcache.xml"));
        factoryBean.setShared(true);
        return factoryBean;
    }

    @Bean
    public CardValidator cardValidator() {
        return new CardValidator();
    }

    @Bean
    // @Conditional()
    public PooledPBEStringEncryptor encryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        encryptor.setAlgorithm("PBEWithMD5AndDES");
        encryptor.setPassword("testdataloader");
        encryptor.setPoolSize(4);
        encryptor.setProviderName("SunJCE");
        // encryptor.setProvider(Bounc);
        return encryptor;
    }

    // @Bean
    // @ConditionalOnMissingBean(StringEncryptor.class)
    // public StringEncryptor stringEncryptor(Environment environment) {
    // return new LazyStringEncryptor(() -> {
    // PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
    // SimpleStringPBEConfig config = new SimpleStringPBEConfig();
    // config.setPassword(getRequiredProperty(environment,
    // "jasypt.encryptor.password"));
    // config.setAlgorithm(getProperty(environment,
    // "jasypt.encryptor.algorithm", "PBEWithMD5AndDES"));
    // config.setKeyObtentionIterations(getProperty(environment,
    // "jasypt.encryptor.keyObtentionIterations", "1000"));
    // config.setPoolSize(getProperty(environment, "jasypt.encryptor.poolSize",
    // "1"));
    // config.setProviderName(getProperty(environment,
    // "jasypt.encryptor.providerName", "SunJCE"));
    // config.setSaltGeneratorClassName(getProperty(environment,
    // "jasypt.encryptor.saltGeneratorClassname",
    // "org.jasypt.salt.RandomSaltGenerator"));
    // config.setStringOutputType(getProperty(environment,
    // "jasypt.encryptor.stringOutputType", "base64"));
    // encryptor.setConfig(config);
    // return encryptor;
    // });
    // }

}
