/**
 * 
 */
package com.koweg.dev.guide.tests.manual;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.DateTime;

/**
 * @author larinde
 *
 */
public class TestCard {
    private String pan;
    private String cid;
    private DateTime expiryDate;

    public TestCard() {
        this.pan = null;
        this.cid = null;
        this.expiryDate = null;
    }

    public TestCard(String pan, String cid, DateTime expiryDate) {
        this.pan = pan;
        this.cid = cid;
        this.expiryDate = expiryDate;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public DateTime getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(DateTime expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((cid == null) ? 0 : cid.hashCode());
        result = prime * result + ((expiryDate == null) ? 0 : expiryDate.hashCode());
        result = prime * result + ((pan == null) ? 0 : pan.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TestCard other = (TestCard) obj;
        if (cid == null) {
            if (other.cid != null)
                return false;
        } else if (!cid.equals(other.cid))
            return false;
        if (expiryDate == null) {
            if (other.expiryDate != null)
                return false;
        } else if (!expiryDate.equals(other.expiryDate))
            return false;
        if (pan == null) {
            if (other.pan != null)
                return false;
        } else if (!pan.equals(other.pan))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TestCard [pan=" + pan + ", cid=" + cid + ", expiryDate=" + expiryDate + "]";
    }

}
