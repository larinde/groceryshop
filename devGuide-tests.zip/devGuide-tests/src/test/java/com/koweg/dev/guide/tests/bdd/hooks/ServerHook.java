
package com.koweg.dev.guide.tests.bdd.hooks;


import cucumber.api.java.After;
import cucumber.api.java.Before;

public class ServerHook {


    @Before("@startServer")
    public static void initLocalServer() throws Exception {
        System.out.println("======== STARTING LOCAL SERVER ========");
    }

    @After("@stopserver")
    public static void shutdownLocalServer() {
        System.out.println("======== SHUTTING DOWN LOCAL SERVER ========");
    }
}
