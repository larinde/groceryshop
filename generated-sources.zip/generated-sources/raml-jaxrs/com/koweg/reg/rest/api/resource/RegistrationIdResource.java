
package com.koweg.reg.rest.api.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import com.koweg.reg.rest.api.model.Partialregistration;
import com.koweg.reg.rest.api.model.Registration_;
import com.koweg.reg.rest.api.resource.support.PATCH;

@Path("{registrationId}")
public interface RegistrationIdResource {


    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param registrationId
     *     
     */
    @GET
    @Produces({
        "application/json"
    })
    RegistrationIdResource.GetByRegistrationIdResponse getByRegistrationId(
        @PathParam("registrationId")
        String registrationId,
        @HeaderParam("x-api-version")
        String xApiVersion)
        throws Exception
    ;

    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param registrationId
     *     
     * @param entity
     *      e.g. {
     *       "lastname": "Khan",
     *       "serviceType": "curr_historic_rates"
     *     }
     *     
     */
    @PATCH
    @Consumes("application/json")
    @Produces({
        "application/json"
    })
    RegistrationIdResource.PatchByRegistrationIdResponse patchByRegistrationId(
        @PathParam("registrationId")
        String registrationId,
        @HeaderParam("x-api-version")
        String xApiVersion, Partialregistration entity)
        throws Exception
    ;

    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param registrationId
     *     
     */
    @DELETE
    RegistrationIdResource.DeleteByRegistrationIdResponse deleteByRegistrationId(
        @PathParam("registrationId")
        String registrationId,
        @HeaderParam("x-api-version")
        String xApiVersion)
        throws Exception
    ;

    public class DeleteByRegistrationIdResponse
        extends com.koweg.reg.rest.api.resource.support.ResponseWrapper
    {


        private DeleteByRegistrationIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         * 
         */
        public static RegistrationIdResource.DeleteByRegistrationIdResponse withNoContent() {
            Response.ResponseBuilder responseBuilder = Response.status(204);
            return new RegistrationIdResource.DeleteByRegistrationIdResponse(responseBuilder.build());
        }

    }

    public class GetByRegistrationIdResponse
        extends com.koweg.reg.rest.api.resource.support.ResponseWrapper
    {


        private GetByRegistrationIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         *  e.g. {
         *   "firstname": "Max",
         *   "lastname": "Mustermann",
         *   "email": "max.mustermann@test.hsbc.com",
         *   "serviceType": "curr_live_rates"
         * }
         * 
         * 
         * @param entity
         *     {
         *       "firstname": "Max",
         *       "lastname": "Mustermann",
         *       "email": "max.mustermann@test.hsbc.com",
         *       "serviceType": "curr_live_rates"
         *     }
         *     
         */
        public static RegistrationIdResource.GetByRegistrationIdResponse withJsonOK(Registration_ entity) {
            Response.ResponseBuilder responseBuilder = Response.status(200).header("Content-Type", "application/json");
            responseBuilder.entity(entity);
            return new RegistrationIdResource.GetByRegistrationIdResponse(responseBuilder.build());
        }

    }

    public class PatchByRegistrationIdResponse
        extends com.koweg.reg.rest.api.resource.support.ResponseWrapper
    {


        private PatchByRegistrationIdResponse(Response delegate) {
            super(delegate);
        }

        /**
         *  e.g. {
         *   "firstname": "Max",
         *   "lastname": "Mustermann",
         *   "email": "max.mustermann@test.hsbc.com",
         *   "serviceType": "curr_live_rates"
         * }
         * 
         * 
         * @param entity
         *     {
         *       "firstname": "Max",
         *       "lastname": "Mustermann",
         *       "email": "max.mustermann@test.hsbc.com",
         *       "serviceType": "curr_live_rates"
         *     }
         *     
         */
        public static RegistrationIdResource.PatchByRegistrationIdResponse withJsonOK(Partialregistration entity) {
            Response.ResponseBuilder responseBuilder = Response.status(200).header("Content-Type", "application/json");
            responseBuilder.entity(entity);
            return new RegistrationIdResource.PatchByRegistrationIdResponse(responseBuilder.build());
        }

    }

}
