
package com.koweg.reg.rest.api.resource;

import java.util.List;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import com.koweg.reg.rest.api.model.Registration;
import com.koweg.reg.rest.api.model.Registration_;

@Path("registrations")
public interface RegistrationsResource {


    /**
     * 
     * @param serviceType
     *     Filter registrations by type. Either curr_live_rates or curr_historic_rates type
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     */
    @GET
    @Produces({
        "application/json"
    })
    RegistrationsResource.GetRegistrationsResponse getRegistrations(
        @HeaderParam("x-api-version")
        String xApiVersion,
        @QueryParam("serviceType")
        String serviceType)
        throws Exception
    ;

    /**
     * 
     * @param xApiVersion
     *     The API implementation version e.g. 1.3.75
     * @param entity
     *      e.g. {
     *       "userId": "43997007",
     *       "firstname": "John",
     *       "lastname": "Smith",
     *       "email": "john.smith@test.hsbc.com",
     *       "serviceType": "curr_live_rates"
     *     }
     *     
     */
    @POST
    @Consumes("application/json")
    RegistrationsResource.PostRegistrationsResponse postRegistrations(
        @HeaderParam("x-api-version")
        String xApiVersion, Registration_ entity)
        throws Exception
    ;

    public class GetRegistrationsResponse
        extends com.koweg.reg.rest.api.resource.support.ResponseWrapper
    {


        private GetRegistrationsResponse(Response delegate) {
            super(delegate);
        }

        /**
         *  e.g. [
         *   {
         *     "userId": "43997495",
         *     "firstname": "John",
         *     "lastname": "Doe",
         *     "email": "john.doe@test.hsbc.com",
         *     "serviceType": "curr_live_rates"
         *   },
         *   {
         *     "userId": "43997497",
         *     "firstname": "Jane",
         *     "lastname": "Doe",
         *     "email": "jane.doe@test.hsbc.com",
         *     "serviceType": "curr_historic_rates"
         *   }
         * ]
         * 
         * 
         * @param entity
         *     [
         *       {
         *         "userId": "43997495",
         *         "firstname": "John",
         *         "lastname": "Doe",
         *         "email": "john.doe@test.hsbc.com",
         *         "serviceType": "curr_live_rates"
         *       },
         *       {
         *         "userId": "43997497",
         *         "firstname": "Jane",
         *         "lastname": "Doe",
         *         "email": "jane.doe@test.hsbc.com",
         *         "serviceType": "curr_historic_rates"
         *       }
         *     ]
         *     
         */
        public static RegistrationsResource.GetRegistrationsResponse withJsonOK(List<Registration> entity) {
            Response.ResponseBuilder responseBuilder = Response.status(200).header("Content-Type", "application/json");
            responseBuilder.entity(entity);
            return new RegistrationsResource.GetRegistrationsResponse(responseBuilder.build());
        }

    }

    public class PostRegistrationsResponse
        extends com.koweg.reg.rest.api.resource.support.ResponseWrapper
    {


        private PostRegistrationsResponse(Response delegate) {
            super(delegate);
        }

        /**
         * 
         * @param location
         *     The URI to the newly created resource e.g. http://localhost:7000/137
         */
        public static RegistrationsResource.PostRegistrationsResponse withCreated(String location) {
            Response.ResponseBuilder responseBuilder = Response.status(201).header("location", location);
            return new RegistrationsResource.PostRegistrationsResponse(responseBuilder.build());
        }

    }

}
