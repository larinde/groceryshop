package com.koweg.raml;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

import com.koweg.raml.rest.RegistrationResource;

@Component
public class JerseyConfig extends ResourceConfig {

    public JerseyConfig() {
        register(RegistrationResource.class);
    }

}