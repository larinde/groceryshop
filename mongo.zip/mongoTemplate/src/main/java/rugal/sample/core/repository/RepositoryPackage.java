package rugal.sample.core.repository;

/**
 *
 * @author Rugal Bernstein
 */
public interface RepositoryPackage
{

}
