package rugal.sample.controller;

import ml.rugal.sshcommon.springmvc.controller.BaseExceptionAction;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 *
 * @author Rugal Bernstein
 */
@Controller
@ControllerAdvice
public class ExceptionAction extends BaseExceptionAction
{

}
