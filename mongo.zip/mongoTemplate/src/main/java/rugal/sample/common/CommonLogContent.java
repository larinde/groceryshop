package rugal.sample.common;

/**
 *
 * @author rugal
 */
public interface CommonLogContent
{

}
