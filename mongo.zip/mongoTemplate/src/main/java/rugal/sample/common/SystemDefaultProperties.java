package rugal.sample.common;

/**
 *
 * Some system level properties.
 *
 * @author Rugal Bernstein
 */
public interface SystemDefaultProperties
{

    String map_range_default = "1000";
}
