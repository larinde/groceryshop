package com.koweg.dev.guide.integration.mule.database.feed;

import javax.sql.DataSource;

import org.springframework.transaction.PlatformTransactionManager;

public interface DatabaseConfig {

    public abstract DataSource dataSource();

    public abstract PlatformTransactionManager transactionManager();

}