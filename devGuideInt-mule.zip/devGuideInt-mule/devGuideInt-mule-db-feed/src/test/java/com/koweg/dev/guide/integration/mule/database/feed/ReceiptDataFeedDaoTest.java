/**
 * 
 */
package com.koweg.dev.guide.integration.mule.database.feed;

import static org.junit.Assert.*;
import static org.hamcrest.core.Is.isA;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author larinde
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = MsSQLServerConfig.class)
public class ReceiptDataFeedDaoTest {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void shouldBeCorrectlyWired() {
        assertThat(jdbcTemplate, is(notNullValue()));
    }


    @Test
    public void shouldSaveReceiptDataFeed() {
        
        fail("Not yet implemented");
    }

}
