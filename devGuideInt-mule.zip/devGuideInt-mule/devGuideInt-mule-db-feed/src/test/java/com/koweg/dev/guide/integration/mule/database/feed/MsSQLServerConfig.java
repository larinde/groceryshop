/**
 * 
 */
package com.koweg.dev.guide.integration.mule.database.feed;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * @author larinde
 *
 */
@Configuration
@PropertySource("classpath:database.properties")
public class MsSQLServerConfig implements DatabaseConfig {

    private static final String DATABASE_PASSWORD = "db.password";
    private static final String DATABASE_URL = "db.url";
    private static final String DATABASE_USERNAME = "db.username";
    private static final String DATABASE_DRIVER = "db.driver";

    @Autowired
    private Environment env;
    
    @Override
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(env.getProperty(DATABASE_DRIVER));
        dataSource.setUrl(env.getProperty(DATABASE_URL));
        dataSource.setPassword(env.getProperty(DATABASE_PASSWORD));
        dataSource.setUsername(env.getProperty(DATABASE_USERNAME));
        return dataSource();
    }

    @Override
    public PlatformTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }

}
