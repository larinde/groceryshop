package com.koweg.dev.payments;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.web.socket.sockjs.client.SockJsClient;
import org.springframework.web.socket.sockjs.client.Transport;
import org.springframework.web.socket.sockjs.client.WebSocketTransport;

public class TestStompClient {

    public TestStompClient() {
    }

    public WebSocketStompClient create() {
        List<Transport> transports = new ArrayList<>(1);
        transports.add(new WebSocketTransport(new StandardWebSocketClient()));
        return  new WebSocketStompClient(new SockJsClient(transports));
    }

}