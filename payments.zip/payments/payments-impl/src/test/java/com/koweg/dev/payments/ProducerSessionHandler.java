package com.koweg.dev.payments;

import java.util.concurrent.atomic.AtomicReference;

import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;

public class ProducerSessionHandler extends StompSessionHandlerAdapter {
    private final int numberOfMessagesToBroadcast;

    private final AtomicReference<Throwable> failure;

    private final String destination;

    private StompSession session;

    public ProducerSessionHandler(String destination, int numberOfMessagesToBroadcast,
            AtomicReference<Throwable> failure) {
        this.numberOfMessagesToBroadcast = numberOfMessagesToBroadcast;
        this.failure = failure;
        this.destination = destination;
    }

    @Override
    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
        this.session = session;
        String payload = "2016";
        try {
            for (int i = 0; i < numberOfMessagesToBroadcast; i++) {
                session.send(destination, payload);
            }
        } catch (Throwable error) {
            error.printStackTrace();
            this.failure.set(error);
        }
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
        Exception exception = new Exception(headers.toString());
        this.failure.set(exception);
    }

    @Override
    public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload,
            Throwable exception) {
        this.failure.set(exception);
    }

    @Override
    public void handleTransportError(StompSession session, Throwable exception) {
        this.failure.set(exception);
    }

}
