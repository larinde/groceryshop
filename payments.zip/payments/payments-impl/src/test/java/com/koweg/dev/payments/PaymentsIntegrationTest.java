package com.koweg.dev.payments;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

import java.util.concurrent.atomic.AtomicReference;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.web.socket.WebSocketHttpHeaders;
import org.springframework.web.socket.messaging.WebSocketStompClient;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.concurrent.ListenableFuture;


@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentsIntegrationTest extends TestStompClient {

    private static WebSocketStompClient stompClient;

    private static final String WEBSOCKET_URI = "ws://localhost:8080/paymentsEndpoint";
    final AtomicReference<Throwable> failure = new AtomicReference<>();

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        stompClient = new TestStompClient().create();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        stompClient = null;
    }


    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    @Test
    public void test() {
        StompHeaders stompHeaders = new StompHeaders();
        String destination = "/payments/paymentHistory";
        String sessionId = "mars-" + System.currentTimeMillis();
        String username  = "larinde";
        String hostname = "localhost";
        stompHeaders.setSession(sessionId);
        stompHeaders.setDestination(destination);
        stompHeaders.setHost(hostname);
        stompHeaders.setLogin(username);

        ProducerSessionHandler producerSessionHandler = new ProducerSessionHandler(destination, 1, failure);
        WebSocketHttpHeaders webSocketHeaders = new WebSocketHttpHeaders();
        ListenableFuture<StompSession> connection = stompClient.connect(WEBSOCKET_URI, webSocketHeaders, stompHeaders, producerSessionHandler );
        assertThat(failure.get(), is(notNullValue()));
    }

}
