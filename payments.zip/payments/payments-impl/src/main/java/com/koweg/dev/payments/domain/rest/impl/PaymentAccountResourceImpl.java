package com.koweg.dev.payments.domain.rest.impl;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.joda.time.DateTime;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.koweg.dev.payments.domain.model.Payment;
import com.koweg.dev.payments.domain.model.PaymentBuilder;
import com.koweg.dev.payments.domain.model.PaymentNotFoundException;

@RestController
public class PaymentAccountResourceImpl implements PaymentAccountResource {

    private static Map<Long, Payment> paymentList;
    private static AtomicLong paymentId = new AtomicLong(0);

    static {
        paymentList = new ConcurrentHashMap<Long, Payment>();
        paymentList.put(paymentId.incrementAndGet(),
                new Payment(paymentId.get(), new BigDecimal("700370.50"), DateTime.now().toDate(), "USD"));
        paymentList.put(paymentId.incrementAndGet(),
                new Payment(paymentId.get(), new BigDecimal("43.3"), DateTime.now().toDate(), "EUR"));
        paymentList.put(paymentId.incrementAndGet(),
                new Payment(paymentId.get(), new BigDecimal("79.7"), DateTime.now().toDate(), "EUR"));
        paymentList.put(paymentId.incrementAndGet(),
                new Payment(paymentId.get(), new BigDecimal("89.7"), DateTime.now().toDate(), "EUR"));
    }

    @Override
    public List<Payment> getPayments() {
        return Collections.list(Collections.enumeration(paymentList.values()));
    }

    @Override
    public Payment getPayment(@PathVariable("id") String id) {
        System.out.println("------------------ retrieving  " + id + " ------------------------");
        return paymentList.get(Long.valueOf(id));
    }

    @Override
    public ResponseEntity<Void> makePayment(Payment payment) {
        System.out.println("------------------ creating  " + payment.toString() + " ------------------------");
        Long id = paymentId.incrementAndGet();
        Payment _pymt = new PaymentBuilder().withId(id)
                                    .withAmount(payment.getAmount())
                                    .withCurrency(payment.getCurrency())
                                    .withDate(payment.getDate())
                                    .build();
        paymentList.put(id, _pymt);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(linkTo(PaymentAccountResourceImpl.class).slash(id).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }

    @Override
    public void cancelPayment(@PathVariable("id") String id) throws PaymentNotFoundException {
        System.out.println("------------------ deleting  " + id + " ------------------------");
        if (paymentList.get(Long.valueOf(id)) == null) {
            throw new PaymentNotFoundException(Long.valueOf(id));
        }
        paymentList.remove(id);
    }

    @Override
    public void updatePayment(Payment update) {
        paymentList.put(update.getId(), update);
    }

    @ExceptionHandler({ PaymentNotFoundException.class })
    protected ResponseEntity<String> notFoundExceptionHandler(Exception ex) {
        return new ResponseEntity<String>(ex.getMessage(), HttpStatus.NOT_FOUND);

    }

}
