package com.koweg.dev.payments.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class PaymentsRepositoryConfig {

}
