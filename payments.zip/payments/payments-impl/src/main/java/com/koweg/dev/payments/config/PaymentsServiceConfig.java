/**
 *
 */
package com.koweg.dev.payments.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.koweg.dev.payments.domain.service.EchoService;
import com.koweg.dev.payments.domain.service.GreetingService;
import com.koweg.dev.payments.domain.service.PaymentHistoryService;
import com.koweg.dev.payments.domain.service.impl.EchoServiceImpl;
import com.koweg.dev.payments.domain.service.impl.GreetingServiceImpl;
import com.koweg.dev.payments.domain.service.impl.PaymentHistoryServiceImpl;

@Configuration
public class PaymentsServiceConfig {

    @Bean
    public EchoService echoService() {
        return new EchoServiceImpl("Did you say \"%s\"????");
    }

    @Bean
    public GreetingService greetingService() {
        return new GreetingServiceImpl();
    }

    @Bean
    public PaymentHistoryService paymentHistoryService() {
        return new PaymentHistoryServiceImpl();

    }

}
