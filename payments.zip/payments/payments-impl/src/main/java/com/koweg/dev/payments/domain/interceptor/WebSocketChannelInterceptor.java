package com.koweg.dev.payments.domain.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;

public class WebSocketChannelInterceptor extends ChannelInterceptorAdapter {

    private static final Logger LOG = LoggerFactory.getLogger(WebSocketChannelInterceptor.class);

    @Override
    public void postSend(Message<?> message, MessageChannel channel, boolean sent) {

        final StompHeaderAccessor accessor = StompHeaderAccessor.wrap(message);

        final String sessionId = accessor.getSessionId();

        if (accessor.getCommand() == null) {
            return;
        }

        switch (accessor.getCommand()) {
        case CONNECT: {
            LOG.info("------- CONNECTING with Sssion ID {} -------", sessionId);
            break;
        }
        case CONNECTED: {
            LOG.info("------- CONNECTED with Sssion ID {} -------", sessionId);
            break;
        }
        case DISCONNECT: {
            LOG.info("------- DISCONNECTING with Sssion ID {} -------", sessionId);
            break;
        }
        case SUBSCRIBE: {
            LOG.info("------- SUBSCRIBING with Sssion ID {} -------", sessionId);
            break;
        }
        case UNSUBSCRIBE: {
            LOG.info("------- UNSUBSCRIBING with Sssion ID {} -------", sessionId);
            break;
        }
        default:
            break;
        }
    }

}
