
package com.koweg.dev.payments.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@EnableAutoConfiguration
@Import({
    PaymentsWebSocketConfig.class,
    PaymentsActorConfig.class,
    PaymentsServiceConfig.class,
    PaymentsRepositoryConfig.class
})
public class PaymentsApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(PaymentsApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(PaymentsApplication.class, args);
    }


}
