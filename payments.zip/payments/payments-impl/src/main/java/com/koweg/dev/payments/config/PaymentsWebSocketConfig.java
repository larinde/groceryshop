package com.koweg.dev.payments.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.handler.PerConnectionWebSocketHandler;

import com.koweg.dev.payments.api.rest.PaymentHistoryResource;
import com.koweg.dev.payments.domain.interceptor.WebSocketChannelInterceptor;
import com.koweg.dev.payments.domain.rest.impl.PaymentAccountResource;
import com.koweg.dev.payments.domain.rest.impl.PaymentAccountResourceImpl;
import com.koweg.dev.payments.domain.service.EchoService;
import com.koweg.dev.payments.domain.service.PaymentHistoryService;
import com.koweg.dev.payments.domain.websocket.impl.EchoWebSocketHandler;
import com.koweg.dev.payments.domain.websocket.impl.PaymentHistoryResourceImpl;

import samples.websocket.snake.SnakeWebSocketHandler;

@EnableWebMvc
@EnableWebSocketMessageBroker
public class PaymentsWebSocketConfig extends AbstractWebSocketMessageBrokerConfigurer implements WebSocketConfigurer {

    @Autowired
    private EchoService echoService;

    @Autowired
    private PaymentHistoryService paymentHistoryService;

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/paymentsEndpoint").withSockJS();

    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.enableSimpleBroker("/queue/", "/topic/");
        // registry.enableStompBrokerRelay("/queue/", "/topic/");
        registry.setApplicationDestinationPrefixes("/payments");
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(echoWebSocketHandler(), "/echo").withSockJS();
        registry.addHandler(snakeWebSocketHandler(), "/snake").withSockJS();
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        super.configureClientInboundChannel(registration);
        registration.setInterceptors(webSocketChannelInterceptor());
    }

    @Override
    public void configureClientOutboundChannel(ChannelRegistration registration) {
        super.configureClientOutboundChannel(registration);
        registration.taskExecutor().corePoolSize(8);
        registration.setInterceptors(webSocketChannelInterceptor());
    }

    @Bean
    public WebSocketHandler echoWebSocketHandler() {
        return new EchoWebSocketHandler(echoService);
    }

    @Bean
    public WebSocketChannelInterceptor webSocketChannelInterceptor() {
        return new WebSocketChannelInterceptor();
    }

    @Bean
    public WebSocketHandler snakeWebSocketHandler() {
        return new PerConnectionWebSocketHandler(SnakeWebSocketHandler.class);
    }

    @Bean
    public PaymentHistoryResource paymentHistoryResource() {
        return new PaymentHistoryResourceImpl(paymentHistoryService);
    }

    @Bean
    public PaymentAccountResource paymentAccountResource() {
        return new PaymentAccountResourceImpl();
    }

}
