package com.koweg.dev.payments.domain.websocket.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;

import com.koweg.dev.payments.api.rest.PaymentHistoryResource;
import com.koweg.dev.payments.domain.service.PaymentHistoryService;

public class PaymentHistoryResourceImpl implements PaymentHistoryResource {

    private static final Logger LOG = LoggerFactory.getLogger(PaymentHistoryResourceImpl.class);

    private final PaymentHistoryService paymentHistoryService;

    public PaymentHistoryResourceImpl(PaymentHistoryService paymentHistoryService) {
        this.paymentHistoryService = paymentHistoryService;
    }

    @Override
    @MessageMapping("/paymentHistory")
    public void getHistory(String message) {
        LOG.info("receiving payment history request {}", message);
    }
}
