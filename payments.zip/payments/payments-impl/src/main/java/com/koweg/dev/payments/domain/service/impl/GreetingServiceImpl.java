
package com.koweg.dev.payments.domain.service.impl;

import com.koweg.dev.payments.domain.service.GreetingService;

public class GreetingServiceImpl implements GreetingService {

    @Override
    public String getGreeting() {
        return "Hello world!";
    }

}
