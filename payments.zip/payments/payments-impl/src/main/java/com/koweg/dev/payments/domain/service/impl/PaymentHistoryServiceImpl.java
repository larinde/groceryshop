package com.koweg.dev.payments.domain.service.impl;

import com.koweg.dev.payments.domain.service.PaymentHistoryService;

public class PaymentHistoryServiceImpl implements PaymentHistoryService {

}
