var paymentsClient = (function() {
    var client = {};
    var stompClient = null;
    var sessionId = null;
    client.isConnected = function() {
        return sessionId != null;
    }

    function setConnected(connected) {
        document.getElementById('connect').disabled = connected;
        document.getElementById('disconnect').disabled = !connected;
        document.getElementById('getPaymentHistory').disabled = !connected;
    }

    client.connect = function(onConnect) {
        if (!onConnect) {
            onConnect = setConnected;
        }

        var socket = new SockJS('/paymentsEndpoint')
        stompClient = Stomp.over(socket)

        var headers = {
            login : 'larinde',
            passcode : 'password',
            'client-id' : 'mars-1'
        };
        stompClient.connect(headers, function(frame) {
            console.log('Connected: ' + frame);
            onConnect(true);
        });
    }

    client.getPaymentHistory = function() {
        var body = {
                'year' : document.getElementById('year').value
        };
        stompClient.send('/payments/paymentHistory', {}, JSON.stringify(body))
    }

});