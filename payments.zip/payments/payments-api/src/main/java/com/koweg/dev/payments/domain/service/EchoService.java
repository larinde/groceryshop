package com.koweg.dev.payments.domain.service;

public interface EchoService {

    String getMessage(String message);

}
