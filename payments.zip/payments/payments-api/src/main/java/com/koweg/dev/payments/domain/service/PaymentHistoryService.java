package com.koweg.dev.payments.domain.service;

public interface PaymentHistoryService {

}
