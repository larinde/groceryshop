package com.koweg.dev.payments.api.rest;

public interface PaymentHistoryResource {

    void getHistory(String message);

}