package com.koweg.dev.payments.api.rest;

import java.util.List;

import com.koweg.dev.payments.domain.model.Payment;
import com.koweg.dev.payments.domain.model.PaymentNotFoundException;

public interface PaymentAccountResource {

//    @RequestMapping(method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
//    @ResponseBody
    public abstract List<Payment> getPayments();

//    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_XML_VALUE })
//    @ResponseBody
    public abstract Payment getPayment(String id);

//    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = { MediaType.APPLICATION_JSON_VALUE })
//    @ResponseBody
    public abstract void makePayment(Payment payment);

//    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
//    @ResponseBody
    public abstract void cancelPayment(String id) throws PaymentNotFoundException;

//    @RequestMapping(method = RequestMethod.PUT, produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_XML_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE })
//    @ResponseBody
    public abstract void updatePayment(Payment payment);

}