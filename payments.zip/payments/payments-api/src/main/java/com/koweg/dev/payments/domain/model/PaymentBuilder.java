package com.koweg.dev.payments.domain.model;

import java.math.BigDecimal;
import java.util.Date;

public class PaymentBuilder {
    private Long id;
    private BigDecimal amount;
    private Date date;
    private String currency;

    public PaymentBuilder() {
    }

    public PaymentBuilder withCurrency(String currency) {
        this.currency = currency;
        return this;
    }

    public PaymentBuilder withId(Long id) {
        this.id = id;
        return this;
    }

    public PaymentBuilder withAmount(BigDecimal amount) {
        this.amount = amount;
        return this;
    }

    public PaymentBuilder withCurr(String curr) {
        this.currency = curr;
        return this;
    }

    public PaymentBuilder withDate(Date date) {
        this.date = date;
        return this;
    }

    public Payment build() {
        return new Payment(id, amount, date, currency);
    }

}
