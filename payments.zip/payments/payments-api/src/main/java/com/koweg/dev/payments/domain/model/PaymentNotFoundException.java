package com.koweg.dev.payments.domain.model;

public class PaymentNotFoundException extends Exception {

    private static final long serialVersionUID = 3282218587829024397L;

    private static final String ERROR_MESSAGE = "Payment %d does not exist";

    public PaymentNotFoundException(Long id) {
        super(String.format(ERROR_MESSAGE, id));
    }


}
