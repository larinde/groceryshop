/**
 *
 */
package com.koweg.dev.payments.domain.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author olarinde.ajai@gmail.com
 *
 */
public final class Payment implements Serializable {
    private static final long serialVersionUID = 4524140864155387996L;
    @JsonProperty("id")
    private final Long id;
    @JsonProperty("amount")
    private final BigDecimal amount;
    @JsonProperty("date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private final Date date;
    @JsonProperty("currency")
    private String currency;

    @JsonCreator
    public Payment(@JsonProperty("id") Long id, @JsonProperty("amount") BigDecimal amount,
            @JsonProperty("date") Date date, @JsonProperty("currency") String currency) {
        this.id = id;
        this.amount = amount;
        this.date = date;
        this.currency = currency;
    }

    public Long getId() {
        return id;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public Date getDate() {
        return date;
    }

    public String getCurrency() {
        return currency;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(date).append(amount).append(currency).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Payment) == false) {
            return false;
        }
        Payment rhs = ((Payment) other);
        return new EqualsBuilder().append(id, rhs.id).append(amount, rhs.amount).append(date, rhs.date)
                .append(currency, rhs.currency).isEquals();
    }

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }

}
